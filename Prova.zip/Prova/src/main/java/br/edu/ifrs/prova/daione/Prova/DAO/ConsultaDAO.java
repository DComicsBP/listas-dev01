package br.edu.ifrs.prova.daione.Prova.DAO;

import br.edu.ifrs.prova.daione.Prova.Entity.Consulta;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author dayon
 */
public interface ConsultaDAO extends CrudRepository<Consulta, Integer> {
    
}
