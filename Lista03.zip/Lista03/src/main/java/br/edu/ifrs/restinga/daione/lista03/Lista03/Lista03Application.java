package br.edu.ifrs.restinga.daione.lista03.Lista03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lista03Application {

	public static void main(String[] args) {
		SpringApplication.run(Lista03Application.class, args);
	}
}
